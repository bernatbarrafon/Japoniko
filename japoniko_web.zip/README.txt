# Japoniko — web

Web estática responsive basada en el diseño de la landing de Japoniko.

## Archivos
- index.html
- styles.css
- script.js

## Para verla
Abre `index.html` en un navegador.

## Para publicarla
Sube los tres archivos al directorio web de `japoniko.es` desde el panel/hosting que utilices.

## Importante
- Las fotografías usan URLs externas de Unsplash como placeholders. Puedes sustituirlas por tus propias fotografías.
- El formulario está preparado visualmente pero todavía NO envía leads a ningún sitio. Hay que conectarlo a un servicio de formularios, CRM o backend.
- Los enlaces legales son placeholders y deben sustituirse por las páginas legales definitivas.
