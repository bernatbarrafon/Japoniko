const toggle=document.querySelector('.menu-toggle');
const nav=document.querySelector('.nav');
toggle?.addEventListener('click',()=>nav.classList.toggle('open'));
document.querySelectorAll('.nav a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));

const form=document.getElementById('leadForm');
const success=document.getElementById('success');
form?.addEventListener('submit',(e)=>{
  e.preventDefault();
  success.style.display='block';
  form.reset();
  // Conecta aquí tu CRM, Formspree, Brevo, Make/Zapier o backend.
});

document.querySelectorAll('a[href="#"]').forEach(a=>a.addEventListener('click',e=>e.preventDefault()));
